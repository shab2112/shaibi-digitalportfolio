# Shaibi Shamsudeen AI Systems Portfolio

This is the complete source of the current static portfolio Site. The website uses plain HTML, CSS, and JavaScript; no package installation or build step is required. The two PDF downloads are included in `dist/`.

## Deploy with Vercel

1. Add the contents of this folder to the root of `shab2112/shaibi-digitalportfolio` on GitHub. Keep the `dist` directory and its contents together.
2. In Vercel, import that GitHub repository as a new project.
3. Set **Framework Preset** to **Other**, leave **Build Command** empty, and set **Output Directory** to `dist`. Keep **Root Directory** as the repository root.
4. Deploy. Future commits to the linked GitHub branch can trigger new deployments.

For a local preview, serve `dist/` with any static file server, for example `python3 -m http.server 8000 --directory dist` and open `http://localhost:8000`.

`.openai/hosting.json` records the original ChatGPT Site's static output location. It is not required by Vercel, but is included to preserve the full source layout.
